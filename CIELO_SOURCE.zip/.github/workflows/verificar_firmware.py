#!/usr/bin/env python3
"""Validacion del artifact: NO graba ni modifica el ATOM."""
import csv,hashlib,json,shutil
from pathlib import Path
r=Path(__file__).resolve().parents[2]
f=r/'.pio/build/atoms3_lite_c124/firmware.bin'
assert f.is_file(), 'No se ha generado firmware.bin'
app=f.read_bytes()
assert app and app[0]==0xE9, 'Cabecera ESP32 invalida'
part={}
with (r/'partitions_8mb.csv').open() as h:
 for name,*fields in csv.reader(x for x in h if x.strip() and not x.lstrip().startswith('#')):
  if len(fields)<4: continue
  typ, subtype, offset, size=fields[:4]
  part[name.strip()]=(int(offset,0),int(size,0))
assert part['app0']==(0x10000,0x330000),part
assert part['app1']==(0x340000,0x330000),part
assert part['spiffs']==(0x670000,0x180000),part
assert part['coredump']==(0x7f0000,0x10000),part
assert len(app) <= part['app0'][1], 'Aplicacion excede particion OTA 3.264 KB'
out=r/'dist';out.mkdir(exist_ok=True)
filename='IWAGUMI_CIELO_96_R4_DEV_SOLO_APLICACION_NO_INSTALAR.bin'
shutil.copy2(f,out/filename)
shutil.copy2(r/'partitions_8mb.csv',out/'partitions_8mb_ORIGINAL.csv')
manifest={'name':filename,'size_bytes':len(app),'sha256':hashlib.sha256(app).hexdigest(),
 'board':'M5Stack ATOMS3 Lite C124 / ESP32-S3 / 8MB DIO',
 'app_partition_size':part['app0'][1],
 'source_status':'R4-dev sin pruebas fisicas',
 'safety':'NO INSTALAR sin validar BLE y recuperar 9.5.3 por USB; no grabar bootloader/partitions/NVS'}
(out/'MANIFIESTO_COMPILACION.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print('BIN OK',len(app),'bytes, sha256',manifest['sha256'])
